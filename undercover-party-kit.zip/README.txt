UNDERCOVER PARTY — KIT GRATUIT
================================

CONTENU
- index.html : le site complet (design responsive, comptes, salons, paramètres, manches, rôles secrets)
- supabase.sql : base de données et règles de sécurité
- README.txt : ce guide

IMPORTANT
Le site n'est pas publié en ligne tant que tu n'as pas suivi les étapes ci-dessous. Le code de la page seul ne suffit pas pour connecter plusieurs téléphones : Supabase sert à gérer les comptes, les salons et la synchronisation en direct. Les offres gratuites peuvent évoluer et ont des limites.

ÉTAPE 1 — CRÉER LE BACKEND GRATUIT
1. Va sur https://supabase.com/ et crée un compte.
2. Crée un nouveau projet. Choisis un mot de passe de base de données et garde-le privé.
3. Dans le projet, ouvre SQL Editor > New query.
4. Ouvre le fichier supabase.sql, copie tout son contenu dans l'éditeur SQL et clique Run.
5. Dans Authentication > Providers, vérifie que Email est activé.
   Pour les premiers tests, tu peux désactiver la confirmation e-mail dans Authentication > Settings (si l'option est disponible). Pour un vrai site public, laisse plutôt la confirmation activée.
6. Dans Project Settings > API, copie le Project URL et la clé publique anon/publishable (JAMAIS la clé secret/service_role).

ÉTAPE 2 — CONNECTER LE SITE À SUPABASE
1. Ouvre index.html dans un éditeur de texte.
2. Cherche les lignes :
   const SUPABASE_URL = "COLLE_ICI_URL_SUPABASE";
   const SUPABASE_ANON_KEY = "COLLE_ICI_CLE_PUBLIQUE_SUPABASE";
3. Remplace les textes entre guillemets par le Project URL et la clé publique de ton projet.
4. Enregistre le fichier. Ne publie jamais la clé service_role ni ton mot de passe de base de données.

ÉTAPE 3 — PUBLIER GRATUITEMENT SUR GITHUB PAGES
1. Va sur https://github.com/ et crée un compte.
2. Clique sur + > New repository.
3. Nomme-le undercover-party, choisis Public, puis Create repository.
4. Clique Add file > Upload files et envoie index.html.
5. Clique Commit changes.
6. Dans le dépôt, ouvre Settings > Pages.
7. Dans Build and deployment, choisis Deploy from a branch, puis branch main et folder /(root), et Save.
8. Attends quelques minutes et ouvre l'adresse affichée dans Settings > Pages.
9. Envoie cette adresse à tes amis. Chacun doit créer son compte sur le site.

À SAVOIR / LIMITES DE CETTE PREMIÈRE VERSION
- L'hôte peut régler le nombre d'Undercover, activer/désactiver Mr. White, régler les durées indicatives et choisir une catégorie.
- L'hôte déclenche manuellement le vote et la révélation. Les champs de durée sont des paramètres pour l'instant : aucun compte à rebours automatique n'est encore programmé.
- Les rôles et mots sont dans une table séparée : chaque joueur ne peut lire que son propre mot secret.
- Le vote est un vote par joueur, et l'hôte clôture le vote. Le site est un starter à tester : vérifie le comportement à plusieurs comptes avant de le partager largement.
- Les rôles sont attribués par le navigateur de l'hôte avant l'appel sécurisé ; ne considère pas ce prototype comme anti-triche pour une compétition publique.
- GitHub Pages héberge des sites statiques. Supabase gère l'authentification et les données en ligne.
- N'utilise pas ton vrai nom complet comme pseudo et ne mets pas d'informations personnelles dans les salons.

AIDE
GitHub Pages : https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
Supabase : https://supabase.com/docs
