-- UNDERCOVER PARTY: schéma Supabase
-- À coller dans Supabase > SQL Editor > New query > Run.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null check (char_length(username) between 2 and 18),
  created_at timestamptz not null default now()
);
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (char_length(code)=6),
  host_id uuid not null references auth.users(id) on delete cascade,
  settings jsonb not null default '{"undercover":1,"mrwhite":true,"discussion":45,"vote":30,"category":"all","hostControls":true}'::jsonb,
  phase text not null default 'lobby' check (phase in ('lobby','discussion','vote','result')),
  round integer not null default 0,
  word_civil text,
  word_undercover text,
  created_at timestamptz not null default now()
);
create table if not exists public.room_players (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  username text not null check (char_length(username) between 2 and 18),
  is_alive boolean not null default true,
  vote_for uuid,
  joined_at timestamptz not null default now(),
  primary key(room_id,user_id)
);
create table if not exists public.player_secrets (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('civil','undercover','mrwhite')),
  secret_word text not null,
  primary key(room_id,user_id)
);

-- Helper RLS function: avoids recursive policies when checking room membership.
create or replace function public.is_room_member(p_room_id uuid, p_user_id uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.room_players rp where rp.room_id=p_room_id and rp.user_id=p_user_id);
$$;
revoke all on function public.is_room_member(uuid,uuid) from public;
grant execute on function public.is_room_member(uuid,uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_players enable row level security;
alter table public.player_secrets enable row level security;

drop policy if exists "profile read own" on public.profiles;
create policy "profile read own" on public.profiles for select to authenticated using (id=auth.uid());
drop policy if exists "profile insert own" on public.profiles;
create policy "profile insert own" on public.profiles for insert to authenticated with check (id=auth.uid());
drop policy if exists "profile update own" on public.profiles;
create policy "profile update own" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

drop policy if exists "members read rooms" on public.rooms;
create policy "members read rooms" on public.rooms for select to authenticated using (
  host_id=auth.uid() or public.is_room_member(id,auth.uid())
);
drop policy if exists "authenticated create room" on public.rooms;
create policy "authenticated create room" on public.rooms for insert to authenticated with check (host_id=auth.uid());
drop policy if exists "host update room" on public.rooms;
create policy "host update room" on public.rooms for update to authenticated using (host_id=auth.uid()) with check (host_id=auth.uid());

drop policy if exists "members read players" on public.room_players;
create policy "members read players" on public.room_players for select to authenticated using (
  public.is_room_member(room_id,auth.uid())
);
drop policy if exists "player joins self" on public.room_players;
create policy "player joins self" on public.room_players for insert to authenticated with check (user_id=auth.uid());
drop policy if exists "player or host update player" on public.room_players;
create policy "player or host update player" on public.room_players for update to authenticated using (
  user_id=auth.uid() or exists(select 1 from public.rooms r where r.id=room_id and r.host_id=auth.uid())
) with check (
  user_id=auth.uid() or exists(select 1 from public.rooms r where r.id=room_id and r.host_id=auth.uid())
);

drop policy if exists "read own secret only" on public.player_secrets;
create policy "read own secret only" on public.player_secrets for select to authenticated using (user_id=auth.uid());

-- A room code can be used to join, but the caller can only add themselves.
create or replace function public.join_room_by_code(p_code text, p_username text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_room public.rooms;
begin
  if auth.uid() is null then raise exception 'Connecte-toi avant de rejoindre.'; end if;
  if char_length(trim(p_username)) < 2 or char_length(trim(p_username)) > 18 then raise exception 'Le pseudo doit faire 2 à 18 caractères.'; end if;
  select * into v_room from public.rooms where code=upper(trim(p_code));
  if not found then raise exception 'Code de salon introuvable.'; end if;
  if v_room.phase <> 'lobby' then raise exception 'Cette partie a déjà commencé.'; end if;
  if (select count(*) from public.room_players where room_id=v_room.id) >= 12 then raise exception 'Ce salon est complet.'; end if;
  insert into public.room_players(room_id,user_id,username) values(v_room.id,auth.uid(),trim(p_username))
  on conflict(room_id,user_id) do update set username=excluded.username;
  return v_room.id;
end; $$;
grant execute on function public.join_room_by_code(text,text) to authenticated;

-- The host assigns roles server-side; each player can read only their own secret.
create or replace function public.start_room_game(p_room_id uuid, p_secrets jsonb, p_word_civil text, p_word_undercover text)
returns void language plpgsql security definer set search_path=public as $$
declare v_host uuid; v_count integer; v_n integer;
begin
  select host_id into v_host from public.rooms where id=p_room_id;
  if v_host is null or v_host <> auth.uid() then raise exception 'Seul l’hôte peut lancer la partie.'; end if;
  select count(*) into v_n from public.room_players where room_id=p_room_id;
  if v_n < 3 then raise exception 'Il faut au moins 3 joueurs.'; end if;
  if jsonb_array_length(p_secrets) <> v_n then raise exception 'Liste des rôles invalide.'; end if;
  if exists(select 1 from jsonb_array_elements(p_secrets) x where (x->>'role') not in ('civil','undercover','mrwhite')) then raise exception 'Rôle invalide.'; end if;
  if (select count(*) from jsonb_array_elements(p_secrets) x where x->>'role'='civil') < 1 then raise exception 'Il faut au moins un Civil.'; end if;
  delete from public.player_secrets where room_id=p_room_id;
  insert into public.player_secrets(room_id,user_id,role,secret_word)
  select p_room_id,(x->>'user_id')::uuid,x->>'role',x->>'secret_word'
  from jsonb_array_elements(p_secrets) x
  where exists(select 1 from public.room_players rp where rp.room_id=p_room_id and rp.user_id=(x->>'user_id')::uuid);
  update public.room_players set is_alive=true,vote_for=null where room_id=p_room_id;
  update public.rooms set phase='discussion',round=round+1,word_civil=null,word_undercover=null where id=p_room_id;
end; $$;
grant execute on function public.start_room_game(uuid,jsonb,text,text) to authenticated;

-- Reveal the pair only after the host ends the vote.
create or replace function public.finish_room_vote(p_room_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_host uuid; v_civil text; v_undercover text; v_target uuid;
begin
  select host_id into v_host from public.rooms where id=p_room_id;
  if v_host is null or v_host <> auth.uid() then raise exception 'Seul l’hôte peut clôturer le vote.'; end if;
  select secret_word into v_civil from public.player_secrets where room_id=p_room_id and role='civil' limit 1;
  select secret_word into v_undercover from public.player_secrets where room_id=p_room_id and role='undercover' limit 1;
  select vote_for into v_target from public.room_players where room_id=p_room_id and vote_for is not null group by vote_for order by count(*) desc limit 1;
  if v_target is not null then update public.room_players set is_alive=false where room_id=p_room_id and user_id=v_target; end if;
  update public.rooms set phase='result',word_civil=v_civil,word_undercover=coalesce(v_undercover,'(aucun Undercover)') where id=p_room_id;
end; $$;
grant execute on function public.finish_room_vote(uuid) to authenticated;

-- Let the frontend receive live updates.
alter publication supabase_realtime add table public.rooms;
alter publication supabase_realtime add table public.room_players;
